If using AddOnPeds mod by Meth0d: 
https://www.gta5-mods.com/scripts/addonpeds-asi-pedselector

AddOnPeds is designed to change the character model back to Michael to prevent game crashes on death. 

This upgraded version removes that code as well as includes an ini file to change the keybindings. 
This version is provided as is and I cannot support issues / additional feature requests for this 3rd party mod.

Installation: 
1. Replace your existing PedSelector.dll in your scripts folder
2. Copy PedSelector.ini to your scripts folder
3. Change keybindings to your suiting

This still requires the latest version of NativeUI for the menu to work
https://github.com/Guad/NativeUI
